package org.jhouse.test.ejb;

import java.io.IOException;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.jhouse.test.ejb.sessionbean.Calculator;


public class CalculatorMain {

	public static void main(String[] args) throws Exception {
		CalculatorMain main = new CalculatorMain();
		Calculator calculator = main.lookup();
		int result = calculator.add(1, 1);
		System.out.println(result);

	}

	public Calculator lookup() throws NamingException, IOException {

		 Properties props = new Properties();

		 props.put( Context.URL_PKG_PREFIXES, "org.jboss.ejb.client.naming" );
		
		// create the context
		Context context = new InitialContext(props);

		final String appName = "";
		final String moduleName = "remote";
		final String distinctName = "";
		final String beanName = "calculator";
		final String viewClassName = Calculator.class.getName();

		return (Calculator) context.lookup("ejb:" + appName + "/" + moduleName
				+ "/" + distinctName + "/" + beanName + "!" + viewClassName);
	}
}
