package com.example.dao;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import com.example.vo.DummyVO;

public class DummyDAO1 extends SqlSessionDaoSupport {
	
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
    	super.setSqlSessionFactory(sqlSessionFactory);
    }

    public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
    	super.setSqlSessionTemplate(sqlSessionTemplate);
    }
	
	public void insertTest(DummyVO dummyVO) {		
		super.getSqlSession().insert("dummyMapper.insertTest", dummyVO);
	} 

	public void updateTest(DummyVO dummyVO) {		
		super.getSqlSession().insert("dummyMapper.updateTest", dummyVO);
	} 
}





