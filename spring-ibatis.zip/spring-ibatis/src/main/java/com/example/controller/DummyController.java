package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.example.service.DummyService;
import com.example.service.DummyService2;
 
@Controller
@RequestMapping("/tx")
public class DummyController {
 
	@Autowired
	DummyService dummyService;
	
	@Autowired
	DummyService2 dummyService2;
	
	@RequestMapping(value="/test1", method = RequestMethod.GET)
	public String test1(ModelMap model) {
		String msg = "tx1 insert = 1 insert";
		try {
			dummyService.test1();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
	
	@RequestMapping(value="/test2", method = RequestMethod.GET)
	public String test2(ModelMap model) {
		String msg = "tx1 insert + tx1 insert fail = 0 insert";
		try {
			dummyService.test2();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
	
	@RequestMapping(value="/test3", method = RequestMethod.GET)
	public String test3(ModelMap model) {
		String msg = "tx1 insert + tx1 update fail = 0 insert";
		try {
			dummyService.test3();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
	
	
	@RequestMapping(value="/test4", method = RequestMethod.GET)
	public String test4(ModelMap model) {
		String msg = "tx2 insert = 1 insert";
		try {
			dummyService2.test1();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
	
	@RequestMapping(value="/test5", method = RequestMethod.GET)
	public String test5(ModelMap model) {
		String msg = "tx2 insert + tx2 insert fail = 0 insert";
		try {
			dummyService2.test2();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
	
	@RequestMapping(value="/test6", method = RequestMethod.GET)
	public String test6(ModelMap model) {
		String msg = "tx2 insert + tx2 update fail = 0 insert";
		try {
			dummyService2.test3();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
	
	@RequestMapping(value="/test7", method = RequestMethod.GET)
	public String test7(ModelMap model) {
		String msg = "tx1 insert + tx2 insert = 2 insert";
		try {
			dummyService.test1();
			dummyService2.test1();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
	
	@RequestMapping(value="/test8", method = RequestMethod.GET)
	public String test8(ModelMap model) {
		String msg = "tx1 insert + (tx2 insert + tx2 insert fail) = 1 insert";
		try {
			dummyService.test1();
			dummyService2.test2();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
	
	@RequestMapping(value="/test9", method = RequestMethod.GET)
	public String test9(ModelMap model) {
		String msg = "tx2 insert +  (tx1 insert + tx1 insert fail) = 1 insert";
		try {
			dummyService2.test1();
			dummyService.test2();
		} catch (Exception e){e.printStackTrace();}
		model.addAttribute("message", msg);
		return "testview";
	}
}