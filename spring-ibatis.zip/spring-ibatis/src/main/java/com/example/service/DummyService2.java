package com.example.service;

public interface DummyService2 {

	public abstract void test1();

	public abstract void test2();

	public abstract void test3();
}
