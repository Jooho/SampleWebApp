package com.example.service.impl;

import org.springframework.stereotype.Service;

import com.example.dao.DummyDAO2;
import com.example.service.DummyService2;
import com.example.vo.DummyVO;


@Service
public class DummyService2Impl implements DummyService2 {
	
	/** Data Transfer Data Access Object */
	private DummyDAO2 dummyDAO2;

	public void setDummyDAO2(DummyDAO2 dummyDAO2) {
		this.dummyDAO2 = dummyDAO2;
	}

	@Override
	public void test1() {
		DummyVO dummyVO= new DummyVO();
		dummyVO.setTransactionName("tx2");
		dummyDAO2.insertTest(dummyVO);
	}
	
	@Override
	public void test2() {
		DummyVO dummyVO = new DummyVO();
		dummyVO.setTransactionName("tx2");
		dummyDAO2.insertTest(dummyVO);
		// Field Length more than the column size
		dummyVO.setTransactionName("123123131231312313123131231312313213131231");
		dummyDAO2.insertTest(dummyVO);
	}

	@Override
	public void test3() {
		DummyVO dummyVO= new DummyVO();
		dummyVO.setTransactionName("tx2");
		dummyDAO2.insertTest(dummyVO);
		// null pointer exception
		dummyDAO2.updateTest(null);
	}
}
