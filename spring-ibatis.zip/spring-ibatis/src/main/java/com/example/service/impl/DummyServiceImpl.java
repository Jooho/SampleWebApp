package com.example.service.impl;

import org.springframework.stereotype.Service;
import com.example.dao.DummyDAO1;
import com.example.service.DummyService;
import com.example.vo.DummyVO;

@Service
public class DummyServiceImpl implements DummyService {
	
	/** Data Transfer Data Access Object */
	private DummyDAO1 dummyDAO1;

	public void setDummyDAO1(DummyDAO1 dummyDAO1) {
		this.dummyDAO1 = dummyDAO1;
	}

	@Override
	public void test1() {
		DummyVO dummyVO= new DummyVO();
		dummyVO.setTransactionName("tx1");
		dummyDAO1.insertTest(dummyVO);
	}
	
	@Override
	public void test2() {
		DummyVO dummyVO = new DummyVO();
		dummyVO.setTransactionName("tx1");
		dummyDAO1.insertTest(dummyVO);
		// Field Length more than the column size
		dummyVO.setTransactionName("123123131231312313123131231312313213131231");
		dummyDAO1.insertTest(dummyVO);
	}

	@Override
	public void test3() {
		DummyVO dummyVO= new DummyVO();
		dummyVO.setTransactionName("tx1");
		dummyDAO1.insertTest(dummyVO);
		// null pointer exception
		dummyDAO1.updateTest(null);
	}
}
