package org.jhouse.test;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import org.jboss.ejb3.annotation.ResourceAdapter;

/**
 * Message-Driven Bean implementation class for: MQMDB
 */
//@MessageDriven(activationConfig = { @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue") })
@MessageDriven( name="MQMDB", 
activationConfig =
{
    @ActivationConfigProperty(propertyName = "destinationType",propertyValue = "javax.jms.Queue"),
    @ActivationConfigProperty(propertyName = "useJNDI", propertyValue = "false"),
    @ActivationConfigProperty(propertyName = "hostName", propertyValue = "localhost"),
    @ActivationConfigProperty(propertyName = "port", propertyValue = "1414"),
//    @ActivationConfigProperty(propertyName = "user", propertyValue = "root"),
//    @ActivationConfigProperty(propertyName = "password", propertyValue = "redhat"),
    @ActivationConfigProperty(propertyName = "channel", propertyValue = "SYSTEM.DEF.SVRCONN"),
    @ActivationConfigProperty(propertyName = "queueManager", propertyValue = "TestQueueManager"),
    @ActivationConfigProperty(propertyName = "destination", propertyValue = "TestQueue"),
    @ActivationConfigProperty(propertyName = "transportType", propertyValue = "CLIENT")
})
@ResourceAdapter(value = "wmq.jmsra-7.1.0.2.rar")
@TransactionAttribute(TransactionAttributeType.NOT_SUPPORTED)
public class MQMDB implements MessageListener {

	/**
	 * Default constructor.
	 */
	public MQMDB() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see MessageListener#onMessage(Message)
	 */
	public void onMessage(Message message) {
		 TextMessage textMessage = (TextMessage) message;
	        try {
	            System.out.println("\n\n\t Message Received by MDB : "+ textMessage.getText());
	        } catch (JMSException e) {
	            e.printStackTrace();
	        }

	}

}
